class MarketAdapter: pass
